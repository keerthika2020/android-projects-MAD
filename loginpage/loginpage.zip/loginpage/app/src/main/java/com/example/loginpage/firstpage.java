package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
//import android.text.InputFilter;
//import android.text.method.HideReturnsTransformationMethod;
//import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
//import android.widget.EditText;

//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

public class firstpage extends AppCompatActivity {
    Button bb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);
        bb = (Button)findViewById(R.id.b2);
        bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });
    }
    public void openMainActivity(){

        Intent in1 = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(in1);
    }
}
